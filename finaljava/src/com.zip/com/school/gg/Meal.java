package com.school.gg;

public class Meal {

	private String soup;
	private String rice;
	private String kimchi;
	private String side;
	private String main;
	
	public Meal(String soup,String rice, String main,String side,String kimchi) {
		this.soup = soup;
		this.rice = rice;
		this.kimchi = kimchi;
		this.side = side;
		this.main = main;
	}

	public String getSoup() {
		return soup;
	}

	public String getRice() {
		return rice;
	}

	public String getKimchi() {
		return kimchi;
	}

	public String getSide() {
		return side;
	}

	public String getMain() {
		return main;
	}

	public void setSoup(String soup) {
		this.soup = soup;
	}

	public void setRice(String rice) {
		this.rice = rice;
	}

	public void setKimchi(String kimchi) {
		this.kimchi = kimchi;
	}

	public void setSide(String side) {
		this.side = side;
	}

	public void setMain(String main) {
		this.main = main;
	}
	
}

