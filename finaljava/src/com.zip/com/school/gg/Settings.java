package com.school.gg;

import java.util.ArrayList;

public class Settings extends School {
	public static ArrayList<Meal> setLunch = new ArrayList<>();

	public void setLunch() {

	}

	public void copyLunch() {

	}
}
