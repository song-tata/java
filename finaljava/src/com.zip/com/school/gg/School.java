package com.school.gg;

import java.util.ArrayList;

public class School {
	private static int serialNumber = 1000;
	private String name;
	
	public static ArrayList<Meal> lunch = new ArrayList<>();
}
