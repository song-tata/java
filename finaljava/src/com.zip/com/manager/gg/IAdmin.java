package com.manager.gg;

public interface IAdmin {
	
	public void addMeal();
	
	public void delMeal(String main);
	
	public void setLunch();
	
	public void copyLunch();
	
	public void checkFeedback();
	
	public void showSetLunch();
}
