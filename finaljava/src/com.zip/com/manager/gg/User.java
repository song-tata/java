package com.manager.gg;

public interface User {

	public int login();
}
