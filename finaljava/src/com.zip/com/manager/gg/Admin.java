package com.manager.gg;

import java.io.FileReader;
import java.util.Scanner;

import com.school.gg.Meal;
import com.school.gg.School;
import com.school.gg.Settings;

public class Admin implements IAdmin, User {

	Scanner in = new Scanner(System.in);

	public void adddummy() {
		School.lunch.add(new Meal("현미밥", "시래기된장국", "너비아니", "시금치무침", "깍두기"));
		School.lunch.add(new Meal("잡곡밥", "김치찌개", "오징어 불고기", "계란말이", "배추김치"));
		School.lunch.add(new Meal("검은콩밥", "선지국", "제육볶음", "무말랭이", "겉절이"));
		School.lunch.add(new Meal("현미밥", "소고기무국", "닭강정", "어묵볶음", "볶음김치"));
		School.lunch.add(new Meal("흰쌀밥", "토란국", "돈까스", "계란후라이", "흰김치"));

	}

	@Override
	public void addMeal() {
		System.out.println("메뉴 추가");
		System.out.println("국");
		String soup = in.next();
		System.out.println("밥");
		String rice = in.next();
		System.out.println("김치");
		String kimchi = in.next();
		System.out.println("사이드");
		String side = in.next();
		System.out.println("메인");
		String main = in.next();

		Meal m1 = new Meal(soup, rice, kimchi, side, main);
		School.lunch.add(m1);
	}

	@Override
	public void delMeal(String main) {
		boolean flag = true;

		while (flag) {
			System.out.printf("%s 가 들어간 식단을 삭제합니다\n", main);
			if (isIt(main)) {
				System.out.println("삭제 하시겠습니까? Y/N");
				String menu = in.next();
				if (menu.toUpperCase().equals("Y")) {
					for (Meal m1 : School.lunch) {
						if (m1.getMain().equals(main)) {
							School.lunch.remove(m1);
							break;
						}
					}
					System.out.println("삭제 완료");
					flag = false;
				} else if (menu.toUpperCase().equals("N")) {
					System.out.println("상위 메뉴로 돌아갑니다.");
					flag = false;
				}
			} else {
				System.out.println("같은 메뉴가 없습니다.");
				flag = false;
			}
		}
	}

	public boolean isIt(String main) {
		boolean isIt = false;
		for (Meal m : School.lunch) {
			if (m.getMain().equals(main)) {
				isIt = true;
				break;
			}
		}
		return isIt;
	}

	@Override
	public void setLunch() {

	}

	@Override
	public void copyLunch() {

	}

	@Override
	public void checkFeedback() {
		try (FileReader fr = new FileReader("StudentFeedback.txt")) {
			int i;
			while ((i = fr.read()) != -1) {
				System.out.print((char) i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println();
		System.out.println("아무 키나 입력하면 이전 메뉴로 돌아갑니다.");
		Scanner scanner = new Scanner(System.in);
		scanner.nextLine(); // 사용자 입력 대기
	}

	@Override
	public void showSetLunch() {
		System.out.println("이번 주 식단입니다.");
		System.out.println("=".repeat(30));
		System.out.println(" ".repeat(3) + "월" + " ".repeat(3) + " ".repeat(3) + "화" + " ".repeat(3) + " ".repeat(3)
				+ "수" + " ".repeat(3) + " ".repeat(3) + "목" + " ".repeat(3) + " ".repeat(3) + "금" + " ".repeat(3));

		for (Meal m1 : Settings.setLunch) {
			System.out.printf("3%s %9s %15s %21s %27s\t\n", m1.getRice(), m1.getSoup(), m1.getMain(), m1.getSide(),
					m1.getKimchi());
		}
	}

	@Override
	public int login() {

		return 1;
	}

	public void showLunch() {
		for (Meal m1 : School.lunch) {
			System.out.printf("%7s %7s %7s %7s %7s\t\n", m1.getRice(), m1.getSoup(), m1.getMain(), m1.getSide(),
					m1.getKimchi());
		}
	}

	public void submenu() {
		boolean flag = true;

		while (flag) {
			System.out.println("1.하루 식단 추가 2.하루 식단 삭제 3. 상위 메뉴로 이동");
			int submenu = in.nextInt();

			if (submenu == 1) {
				addMeal();
			} else if (submenu == 2) {
				showLunch();
				System.out.println("삭제할 식단의 메인 메뉴를 골라주세요.");
				String main = in.next();
				delMeal(main);
			} else if (submenu == 3) {
				System.out.println("상위 메뉴로 이동합니다.");
				return;
			} else
				System.out.println("잘못 입력하셨습니다. 다시 입력하세요");
		}

	}

	public void setsubmenu() {
		boolean flag = true;

		while (flag) {
			System.out.println("식단 만들기 메뉴입니다.");
			System.out.println("1.식단 생성 2.랜덤 식단 생성 3. 상위 메뉴로 이동");
			int submenu = in.nextInt();

			if (submenu == 1) {
				copyLunch();
			} else if (submenu == 2) {
				setLunch();
			} else if (submenu == 3) {
				System.out.println("상위 메뉴로 이동합니다.");
				return;
			} else
				System.out.println("잘못 입력하셨습니다. 다시 입력하세요");
		}

	}

	public void showMenu() {
		System.out.println("=".repeat(30));
		System.out.println("관리자 메뉴입니다.");
		System.out.println("=".repeat(30));
		System.out.println("메뉴를 선택해주세요");
		System.out.println("1. 학교의 식품 관리하기");
		System.out.println("2. 일주일 식단 생성하기");
		System.out.println("3. 일주일 식단 조회하기");
		System.out.println("4. 학생 피드백 조회하기");
		System.out.println("5. 상위 메뉴로 이동하기");
	}

	public void main() {
		boolean run = true;
		{
			int menu;

			while (run) {
				showMenu();
				menu = in.nextInt();

				switch (menu) {
				case 1:
					submenu();
					break;
				case 2:
					setsubmenu();
					break;

				case 3:
					showSetLunch();
					break;

				case 4:
					checkFeedback();
					break;

				case 5:
					System.out.println("관리자 메뉴를 종료합니다.");
					return;

				default:
					System.out.println("잘못 입력하셨습니다.");
					break;
				}
			}

		}

	}
}
